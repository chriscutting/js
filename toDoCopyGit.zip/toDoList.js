const express = require("express");
const bodyParser = require("body-parser");

const app = express();

app.get("/", function(req, res){
  res.send("Hewwo");
});


app.listen(3000, function(){
  console.log("This is your server");
});
