const express = require("express");
const bodyParser = require("body-parser");
const ejs = require("ejs");

const app = express();

app.set("view engine", "ejs");

app.get("/", function(req, res){

  res.render("list", {foo:"FOO"});


  var day = "";
  var today = new Date();
  var currentDay = today.getDay();
  if (currentDay === 0){
    var day = "Sunday";
    res.render("list", {typeOfDay: day});
  }
  else if(currentDay === 1) {
    var day = "Monday";
    res.render("list", {typeOfDay: day});
    }
    else if (currentDay === 2) {
      var day = "Tuesday";
      res.render("list", {typeOfDay: day});
    }
    else if (currentDay === 3) {
      var day = "Wednesday";
      res.render("list", {typeOfDay: day});
    }
    else if (currentDay === 4) {
      var day = "Thursday";
      res.render("list", {typeOfDay: day});
    }
    else if (currentDay === 5) {
      var day = "Friday";
      res.render("list", {typeOfDay: day});
    }
    else if(currentDay === 6) {
      var day = "Saturday";
      res.render("list", {typeOfDay: day});
    }
    else{
      console.log("You broke it!");
    }
});


app.listen(3000, function(){
  console.log("This is your server");
});
